package com.example.pregnancyapp;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;


public class Settings extends Activity {
	
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_settings);
	                               
		final EditText et;
		final EditText num;
		final Button b;
	       
		et = (EditText) findViewById(R.id.nameInput);
		num = (EditText) findViewById(R.id.emergenyNumber);
		b = (Button) findViewById(R.id.button1);
	       
	                                
		b.setOnClickListener(new OnClickListener(){
			public void onClick(View v){
				String text=et.getText().toString();
				String numb = num.getText().toString();
				Toast msg = Toast.makeText(getBaseContext(),text, Toast.LENGTH_LONG);
				Toast msg2 = Toast.makeText(getBaseContext(),numb, Toast.LENGTH_LONG);
				msg.show();
				msg2.show();
			}
		});
	}
}
